require('dotenv').config();
export const SECRET_KEY = process.env.SECRET_KEY;
export const REFRESH_SECRET_KEY = process.env.REFRESH_TOKEN_SECRET_KEY;
