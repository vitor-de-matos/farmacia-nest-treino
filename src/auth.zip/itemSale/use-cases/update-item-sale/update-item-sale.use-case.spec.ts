import { BadRequestException, NotFoundException } from '@nestjs/common';
import { IMidiaRepo } from 'src/media/models/interface/midia-repo.interface';
import { UpdateMidiaUseCase } from 'src/media/use-case/update-media/update-media.use-case';
import { IProductRepo } from 'src/products/models/interface/produto-repo.interface';
import { ArchivesManagementJob } from 'src/shared/job/images-vids/archives-management.job';

describe('UpdateMidiaUseCase', () => {
  let useCase: UpdateMidiaUseCase;
  let mediaRepository: jest.Mocked<IMidiaRepo>;
  let productRepository: jest.Mocked<IProductRepo>;
  let archivesJob: jest.Mocked<ArchivesManagementJob>;

  beforeEach(() => {
    mediaRepository = {
      findById: jest.fn(),
      update: jest.fn(),
    } as any;

    productRepository = {} as any;
    archivesJob = {
      saveArchive: jest.fn(),
    } as any;

    useCase = new UpdateMidiaUseCase(
      mediaRepository,
      productRepository,
      archivesJob,
    );
  });

  it('deve lançar NotFoundException se a mídia não for encontrada', async () => {
    mediaRepository.findById.mockResolvedValue(null);

    await expect(useCase.update(1, {} as any)).rejects.toThrow(
      NotFoundException,
    );
  });

  it('deve chamar mediaRepository.update com os dados corretos', async () => {
    const mockMidia = {
      id: 1,
      name: 'teste',
      icon: true,
      url: 'testes',
      createdAt: null,
      product: null,
    };
    mediaRepository.findById.mockResolvedValue(mockMidia);

    const dto = {
      title: 'Nova mídia',
      productId: 10,
    };

    await useCase.update(1, dto as any);

    expect(mediaRepository.update).toHaveBeenCalledWith(1, dto);
  });

  it('deve processar arquivo se enviado no DTO', async () => {
    const mockMidia = {
      id: 1,
      name: 'teste',
      icon: true,
      url: 'testes',
      createdAt: null,
      product: null,
    };
    mediaRepository.findById.mockResolvedValue(mockMidia);

    const dto = {
      archive: 'arquivo.jpg',
      productId: 10,
    };

    await useCase.update(1, dto as any);

    expect(archivesJob.saveArchive).toHaveBeenCalledWith('arquivo.jpg');
  });
});
